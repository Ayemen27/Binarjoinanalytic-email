<footer class="dashboard-footer">
    <div class="row justify-content-between">
        <div class="col-auto">
            <p class="mb-0">{{ env('APP_NAME') }} © <span data-year></span>
                {{ __(' - All rights reserved.') }}</p>
        </div>
        <div class="col-auto">
            <p class="mb-0">{{ __('Crafted with ❤️ by ') }} <a target="_blank" href="https://lobage.com">Lobage</a></p>
        </div>
    </div>
</footer>
