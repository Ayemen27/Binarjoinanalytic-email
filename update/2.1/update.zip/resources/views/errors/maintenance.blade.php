@extends('errors.layout')

@section('code', 'maintenance')

@section('title', getSetting('maintenance_title'))
@section('message', getSetting('maintenance_message'))
