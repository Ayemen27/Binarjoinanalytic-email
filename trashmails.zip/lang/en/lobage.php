<?php

return [

    'toastr' => [
        'update' => translate('Updated successfully', 'alerts'),
        'delete' => translate('Deleted successfully.', 'alerts'),
        'success' => translate('Added successfully', 'alerts'),
    ],


];