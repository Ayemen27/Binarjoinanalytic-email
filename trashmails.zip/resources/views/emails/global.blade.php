<x-mail::message>

    {!! $body !!}

</x-mail::message>
